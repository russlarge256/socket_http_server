import socket
import sys
import traceback
import os
from webroot import make_time

webroot = r"C:\Python230\lesson03\Russ_Github_versions\socket-http-server\webroot"
images = r"C:\Python230\lesson03\Russ_Github_versions\socket-http-server\webroot\images"


def response_ok(body=b"This is a minimal response", mimetype=b"text/plain"):

    # TODO: Implement response_ok
    return b"\r\n".join([
        b"HTTP/1.1 200 OK",
        b"Content-Type: " + mimetype,
        b"",
        body,
    ])


def response_method_not_allowed():
    """Returns a 405 Method Not Allowed response"""

    # TODO: Implement response_method_not_allowed

    return b"/r/n".join([
        b"HTTP/1.1 405 Method Not Allowed",
        b"",
        b"You can't do that on this server!"
    ])


def response_not_found():
    """Returns a 404 Not Found response"""

    # TODO: Implement response_not_found
    return b"/r/n".join([
        b"HTTP/1.1 404 Method Not Found",
        b"",
        b"You can't do that on this server!"
    ])


def parse_request(request):

    # TODO: implement parse_request
    method, path, version = request.split("\r\n")[0].split(" ")

    if method != "GET":
        raise NotImplementedError

    if str(path).__contains__('test.txt'):
        response_not_found()

    return path


def image_to_bytes(path):

    with open(path, "rb") as image:

        f = image.read()
        b = bytearray(f)

        return b


def response_path(path):

    # TODO: Raise a NameError if the requested content is not present
    # TODO: Fill in the appropriate content and mime_type give the path.

    p = path[1:]

    content = bytes(os.path.join(webroot, p), encoding="utf-8")
    mime_type = b"text/plain"

    if p == 'sample.txt':
        fullpath = os.path.join(webroot, p)
        with open(fullpath, 'rb') as file:
            reader = file.read()
        # content = bytes(reader, encoding='utf-8')
        content = reader
        mime_type = b"text/plain"

    elif p == 'favicon.ico':
        content = image_to_bytes(os.path.join(webroot, p))
        mime_type = b"image/x-icon"

    elif p == 'make_time.py':
        content = bytes(make_time.show_time(), encoding="utf=8")
        mime_type = b"text/html"

    elif p.__contains__('sample_1.png'):
        content = image_to_bytes(os.path.join(webroot, "images", p))
        mime_type = b"image/png"

    elif p.__contains__('JPEG_example.jpg') or\
            p.__contains__('Sample_Scene_Balls.jpg'):
        content = image_to_bytes(os.path.join(webroot, "images", p))
        mime_type = b"image/jpg"

    elif p.__contains__('a_web_page.html'):
        fullpath = os.path.join(webroot, p)
        with open(fullpath, 'r', encoding="utf-8") as file:
            reader = file.read()
        content = bytes(reader, encoding='utf-8')
        mime_type = b"text/html"

    elif p.__contains__('images'):
        items = os.listdir(images)
        list = ""
        for item in images:
            with open(list, 'w') as ok:
                ok.write(item)

        content = bytes('all_images', encoding="utf-8")



    else:
        response_not_found()
        return NameError

    return content, mime_type


def server(log_buffer=sys.stderr):
    address = ('127.0.0.1', 10000)
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    print("making a server on {0}:{1}".format(*address), file=log_buffer)
    sock.bind(address)
    sock.listen(1)

    try:
        while True:
            print('waiting for a connection', file=log_buffer)
            conn, addr = sock.accept()  # blocking
            try:
                print('connection - {0}:{1}'.format(*addr), file=log_buffer)

                request = ''
                while True:
                    data = conn.recv(1024)
                    request += data.decode('utf8')

                    if '\r\n\r\n' in request:
                        break

                print("Request received:\n{}\n\n".format(request))

                # TODO: Use parse_request to retrieve the path from the request.
                # TODO: Use response_path to retrieve the content and the mimetype,
                # TODO; If parse_request raised a NotImplementedError, then let
                # response be a method_not_allowed response. If response_path raised
                # a NameError, then let response be a not_found response. Else,
                # use the content and mimetype from response_path to build a
                # response_ok.

                try:
                    path = parse_request(request)

                    # t = [items for items in os.listdir(webroot)]
                    # if path not in t:
                    #     print(f"{path} not in here")
                    #     response_not_found()

                    response = response_ok(
                        body=response_path(path)[0], mimetype=response_path(path)[1]
                    )

                except NotImplementedError:
                    response = response_method_not_allowed()

                conn.sendall(response)
            except:
                traceback.print_exc()
            finally:
                conn.close()

    except KeyboardInterrupt:
        sock.close()
        return
    except:
        traceback.print_exc()


if __name__ == '__main__':
    server()
    sys.exit(0)


