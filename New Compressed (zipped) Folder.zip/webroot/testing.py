import os

webroot = r"C:\Python230\lesson03\Russ_Github_versions\socket-http-server\webroot"

t = [items for items in os.listdir(webroot)]

print(t)

if 'eafew.txt' not in t:
    print('not in here')